<footer class="footer pt-0">
    <div class="row align-items-center justify-content-lg-between">
        <div class="col-lg-12">
            <div class="copyright text-center  text-lg-left  text-muted">
                &copy; 2020 SISTEM RESERVASI MEJA RUANG SEDUH COFFEE
            </div>
        </div>
    </div>
</footer>
</div>
</div>
<!-- Argon Scripts -->
<!-- Core -->
<script src="<?php echo base_url('assets/vendor/jquery/dist/jquery.min.js') ?>"></script>
<script src="<?php echo base_url('assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js') ?>"></script>
<script src="<?php echo base_url('assets/vendor/js-cookie/js.cookie.js') ?>"></script>
<script src="<?php echo base_url('assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js') ?>"></script>
<script src="<?php echo base_url('assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js') ?>"></script>
<!-- Argon JS -->
<script src="<?php echo base_url('assets/js/argon.js?v=1.2.0') ?>"></script>

<script src="<?= base_url('assets/vendor/bootstrap-table/bootstrap-table.min.js') ?>"></script>
<script src="<?= base_url('assets/vendor/bootstrap-table/bootstrap-table-id-ID.js') ?>"></script>
</body>

</html>